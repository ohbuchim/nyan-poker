---
description: GitHub Issueの実装を行う（issue番号を引数として指定）
---

# Implement GitHub Issue

指定されたIssue番号の実装をissue-developerエージェントに依頼します。

**引数**: $ARGUMENTS

---

まず、引数として渡されたIssue番号を確認してください。

引数が空または無効な場合は、以下のメッセージを表示してください：
```
エラー: Issue番号を指定してください。
使用方法: /implement-issue <issue番号>
例: /implement-issue 1
```

引数が有効な場合（数字が指定されている場合）は、Task toolを使用してissue-developerサブエージェントを起動し、Issue #$ARGUMENTS の実装を依頼してください。

Task toolの呼び出しパラメータ：
- subagent_type: "issue-developer"
- description: "Issue #$ARGUMENTS の実装"
- prompt: 以下の内容

```
GitHub Issue #$ARGUMENTS の実装を行ってください。

## 実行手順

1. `gh issue view $ARGUMENTS` でIssueの詳細を確認
2. 要件と受け入れ条件を把握
3. 関連ドキュメント（docs/requirements.md, docs/spec.md, mock/index.html）を参照
4. TodoWriteでタスクリストを作成
5. ブランチを作成（例: feature/$ARGUMENTS-<簡潔な説明>）
6. 実装を開始
7. 実装完了後、code-reviewer-jaでコードレビューを実施
8. ユニットテストを作成・実行（カバレッジ90%以上、成功率100%を目標）
9. すべてのテストが通ったらプルリクエストを作成

## 重要事項

- 既存のコードパターンに従うこと
- mock/index.htmlを参照してUIの一貫性を確認すること
- エラーが発生したら原因を特定し修正すること
- 各ステップ完了時に進捗を報告すること

最後に実装結果のサマリー（ブランチ名、変更ファイル、テスト結果、PRのURL）を報告してください。
```
