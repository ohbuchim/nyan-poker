---
description: GitHub Issueの実装からプルリクマージまでを行う（1つ以上のissue番号を引数として指定）
---

# Implement GitHub Issues

指定された複数のIssue番号の実装をissue-pipelineエージェントに依頼し、並列で処理します。

**引数**: $ARGUMENTS（スペースまたはカンマ区切りで複数指定可能）

---

## 処理手順

### 1. 引数の解析

引数として渡されたIssue番号を解析してください。

- スペース区切り: `1 2 3`
- カンマ区切り: `1,2,3`
- ハイフン（範囲指定）: `1-5` → 1, 2, 3, 4, 5 に展開
- 混在: `1, 2-5 8` → 1, 2, 3, 4, 5, 8 に展開

**範囲指定のルール:**
- `N-M` 形式で、NからMまでの連続したIssue番号に展開する
- N > M の場合（例: `5-1`）は無効として無視する
- 範囲が大きすぎる場合（100件以上）はエラーとする

数字、ハイフン、スペース、カンマ以外の文字は無視してください。重複するIssue番号は1つにまとめてください。

### 2. バリデーション

引数が空または有効なIssue番号が1つもない場合は、以下のメッセージを表示して終了してください：

```
エラー: Issue番号を1つ以上指定してください。
使用方法: /auto-implement-issue <issue番号> [issue番号...]
例: /auto-implement-issue 1
例: /auto-implement-issue 1 2 3
例: /auto-implement-issue 1,2,3
例: /auto-implement-issue 1-5（1から5まで）
例: /auto-implement-issue 1-3 7 10-12（1,2,3,7,10,11,12）
```

範囲が100件以上の場合は、以下のメッセージを表示して終了してください：

```
エラー: 指定されたIssue数が多すぎます（100件以上）。
範囲を絞って再度実行してください。
```

### 3. 並列実行（Git Worktree使用）

有効なIssue番号ごとに、Task toolを使用してissue-pipelineサブエージェントを**並列で**起動してください。

**重要**: 複数のIssueがある場合、**すべてのTask tool呼び出しを単一のメッセージで行う**ことで並列実行を実現してください。

#### 3.1 Worktreeのセットアップ（2つ以上のIssueの場合）

複数のIssueを並列実行する場合、事前にgit worktreeを作成します。

**重要**: worktreeは**プロジェクトディレクトリ内部**（`.worktrees/`）に作成してください。
バックグラウンドエージェントはプロジェクト外のディレクトリにアクセスできません。

```bash
# mainを最新化
git checkout main
git pull origin main

# worktree用ディレクトリを作成
mkdir -p .worktrees

# 各Issue用のworktreeを作成
# パス: .worktrees/issue<番号>
# ブランチ: feature/<番号>-<説明> または fix/<番号>-<説明>
git worktree add .worktrees/issue<番号> -b <type>/<番号>-<簡潔な説明>
```

例（Issue #5, #6, #7を並列実行する場合）:
```bash
git checkout main && git pull origin main
mkdir -p .worktrees
git worktree add .worktrees/issue5 -b feature/5-deck-management
git worktree add .worktrees/issue6 -b feature/6-role-calculator
git worktree add .worktrees/issue7 -b feature/7-common-ui
```

**ブランチ名の決定方法**:
1. `gh issue view <番号>` でIssueのタイトルとラベルを確認
2. ラベルに `bug` があれば `fix/`、それ以外は `feature/` を使用
3. タイトルから簡潔な英語の説明を生成（ケバブケース）

#### 3.2 エージェントの起動

各Task toolの呼び出しパラメータ：

- subagent_type: "issue-pipeline"
- description: "Issue #<番号> パイプライン実行"
- run_in_background: true（複数Issueの場合）
- prompt: 以下の内容（<番号>と<worktree_path>を置換。worktree_pathは `.worktrees/issue<番号>` の絶対パス）

```
GitHub Issue #<番号> の実装からプルリクエストのマージまでを一貫して行ってください。

## Worktree情報（並列実行モード）

worktree_path: <プロジェクトルート>/.worktrees/issue<番号>

**重要**: 全ての作業は上記worktree_path内で行ってください。
- ファイルの読み書きは全てworktree_path配下のパスを使用
- gitコマンドはworktree_path内で実行
- 他のworktreeやメインリポジトリには触れない

## 処理内容

issue-pipelineは以下の処理を自動で実行します：
1. Issueの詳細確認
2. 実装
3. テスト作成・実行
4. コードレビュー
5. PR作成
6. PRレビュー
7. 指摘事項の修正
8. マージ
9. 作業完了報告（worktree削除は呼び出し元が行う）

## 参照すべきドキュメント

- docs/requirements.md: 要件定義
- docs/spec.md: 仕様書
- mock/index.html: UIモック

## 重要事項

- 既存のコードパターンに従うこと
- mock/index.htmlを参照してUIの一貫性を確認すること
- テストはカバレッジ90%以上、成功率100%を目標とすること
- エラーが発生したら原因を特定し修正すること
- 他のIssueと競合が発生した場合は、最新のmainをリベースして解決すること
```

#### 3.3 単一Issueの場合

Issue数が1つの場合は、worktreeを使用せず通常モードで実行します（promptからworktree_path行を削除）。

### 4. 結果の集約

すべてのエージェントの処理が完了したら、各Issueの結果を一覧でまとめて報告してください。

```
## 実行結果サマリー

| Issue | 状態 | PR | マージ |
|-------|------|----|----|
| #1 | ✅ 完了 | #10 | ✅ マージ済み |
| #2 | ✅ 完了 | #11 | ✅ マージ済み |
| #3 | ❌ 失敗 | - | - |

### 詳細

（各Issueの詳細な結果）
```

### 5. Worktreeのクリーンアップ（並列実行時のみ）

全エージェントの処理が完了したら、worktreeを削除します：

```bash
# 各worktreeを削除
git worktree remove .worktrees/issue<番号> --force

# 例
git worktree remove .worktrees/issue5 --force
git worktree remove .worktrees/issue6 --force
git worktree remove .worktrees/issue7 --force

# worktreeの一覧を確認（削除されていることを確認）
git worktree list

# .worktreesディレクトリが空なら削除
rmdir .worktrees 2>/dev/null || true

# mainブランチを最新化
git checkout main
git pull origin main

# マージ済みのローカルブランチを削除
git branch -d feature/5-deck-management
git branch -d feature/6-role-calculator
git branch -d feature/7-common-ui

# リモート追跡ブランチをクリーンアップ
git fetch --prune
```

**注意事項**:
- 失敗したIssueのworktreeは、デバッグのため削除せずに残すことも可能
- `--force` オプションは、未コミットの変更がある場合に必要
- worktreeが残っている場合、同名のブランチを削除できないため先にworktreeを削除する
